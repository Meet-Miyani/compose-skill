package com.example.app

import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import org.jetbrains.compose.resources.stringResource
import notes.composeapp.generated.resources.Res
import notes.composeapp.generated.resources.app_title

/** Thin desktop entry point. Starts DI and renders the shared App. */
fun main() {
    initKoin()
    application {
        Window(onCloseRequest = ::exitApplication, title = stringResource(Res.string.app_title)) {
            App()
        }
    }
}
