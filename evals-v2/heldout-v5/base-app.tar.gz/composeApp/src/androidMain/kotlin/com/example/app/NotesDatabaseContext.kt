package com.example.app

import android.content.Context
import com.example.feature.notes.data.local.setNotesDatabaseContext

fun configureNotesDatabase(context: Context) = setNotesDatabaseContext(context)
