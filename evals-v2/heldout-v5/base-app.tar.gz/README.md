# Base Notes app

The app lists local notes, creates a blank note, and edits and saves a note title. The list is the start screen. Notes persist with Room and bundled SQLite on Android, iOS, and desktop.

## Modules

- `:feature:notes` owns the list and detail screens, ViewModels, repository, Room database, and platform database builders.
- `:composeApp` owns navigation and app dependency injection.
- `:androidApp` is the Android shell. `:core:mvi`, `:core:error`, and `:core:designsystem` supply shared support.

## Verification

- `./gradlew :composeApp:jvmJar :androidApp:assembleDebug :composeApp:linkDebugFrameworkIosSimulatorArm64 allTests` — passed.
- `bash scripts/composekit/run-checks.sh .` — passed, 11 checks.
