package com.example.feature.notes.data.local

import androidx.room.Room
import androidx.room.RoomDatabase
import java.io.File

internal actual fun notesDatabaseBuilder(): RoomDatabase.Builder<NotesDatabase> {
    val directory = File(System.getProperty("user.home"), ".notes-app").apply { mkdirs() }
    return Room.databaseBuilder<NotesDatabase>(name = File(directory, "notes.db").absolutePath)
}
