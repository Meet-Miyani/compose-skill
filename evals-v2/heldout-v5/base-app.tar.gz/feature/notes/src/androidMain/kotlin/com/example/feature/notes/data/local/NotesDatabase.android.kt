package com.example.feature.notes.data.local

import android.content.Context
import androidx.room.Room
import androidx.room.RoomDatabase

private lateinit var applicationContext: Context

fun setNotesDatabaseContext(context: Context) {
    applicationContext = context.applicationContext
}

internal actual fun notesDatabaseBuilder(): RoomDatabase.Builder<NotesDatabase> =
    Room.databaseBuilder<NotesDatabase>(
        context = applicationContext,
        name = applicationContext.getDatabasePath("notes.db").absolutePath,
    )
