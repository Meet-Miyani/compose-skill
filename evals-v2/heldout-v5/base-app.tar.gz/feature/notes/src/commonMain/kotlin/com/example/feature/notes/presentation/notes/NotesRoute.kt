/**
 * Lifecycle-aware wrapper for the Notes destination.
 *
 * Koin-free: the composition root resolves the ViewModel and passes it in.
 * This wrapper owns lifecycle, effect collection, and error forwarding only.
 */
package com.example.feature.notes.presentation.notes

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.LifecycleStartEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.mvi.CollectEffect
import com.example.designsystem.error.HandleAppErrors

/** Entry for the Notes destination; owns lifecycle, effect collection, and error forwarding. */
@Composable
fun NotesRoute(
    viewModel: NotesViewModel,
    noteId: Long,
    onEffect: suspend (NotesUiEffect) -> Unit,
) {
    LifecycleStartEffect(noteId) {
        viewModel.onAction(NotesUiAction.OnScreenStarted)
        onStopOrDispose {}
    }
    val state by viewModel.state.collectAsStateWithLifecycle()
    CollectEffect(viewModel.effect) { effect -> onEffect(effect) }
    HandleAppErrors(viewModel.errors)
    NotesScreen(
        state = state,
        onTitleChange = { viewModel.onAction(NotesUiAction.OnTitleChanged(it)) },
        onSave = { viewModel.onAction(NotesUiAction.OnSaveClick) },
        onRetry = {
            // Retry holds the error it retries; no-op when no error is showing.
            viewModel.onAction(NotesUiAction.OnRetryClick(state.error ?: return@NotesScreen))
        },
        onBack = { viewModel.onAction(NotesUiAction.OnBackClick) },
    )
}
