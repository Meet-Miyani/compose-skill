package com.example.feature.notes.presentation.list

import com.example.core.error.AppError
import com.example.core.mvi.UiAction
import com.example.core.mvi.UiEffect
import com.example.core.mvi.UiState
import com.example.feature.notes.domain.model.Note

data class NotesListUiState(
    val items: List<Note> = emptyList(),
    val isLoading: Boolean = true,
    val error: AppError? = null,
) : UiState

sealed interface NotesListUiAction : UiAction {
    data object OnScreenStarted : NotesListUiAction
    data object OnAddClick : NotesListUiAction
    data class OnNoteClick(val id: Long) : NotesListUiAction
    data object OnRetryClick : NotesListUiAction
}

sealed interface NotesListUiEffect : UiEffect {
    data class OpenNote(val id: Long) : NotesListUiEffect
}
