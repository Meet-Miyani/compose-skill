package com.example.feature.notes.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.feature.notes.domain.model.Note

@Entity(tableName = "notes")
internal data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val body: String = "",
)

internal fun NoteEntity.toDomain(): Note = Note(id = id, title = title, body = body, updatedAt = null)
