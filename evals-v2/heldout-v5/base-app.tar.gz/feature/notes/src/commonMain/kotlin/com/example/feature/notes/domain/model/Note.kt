/** Domain note aggregate for the Notes feature. */
package com.example.feature.notes.domain.model

/** Domain representation of a single note record. */
public data class Note(
    val id: Long,
    val title: String?,
    val body: String?,
    val updatedAt: kotlin.time.Instant?,
    val isArchived: Boolean = false,
)
