/**
 * Koin module for the Notes feature slice.
 *
 * Notes bindings stay inside the feature package.
 */
package com.example.feature.notes.di

import com.example.feature.notes.data.repository.DefaultNotesRepository
import com.example.feature.notes.data.local.NotesDatabase
import com.example.feature.notes.data.local.NotesDao
import com.example.feature.notes.data.local.createNotesDatabase
import com.example.feature.notes.domain.repository.NotesRepository
import org.koin.core.annotation.ComponentScan
import org.koin.core.annotation.Module
import org.koin.core.annotation.Single

/**
 * Feature dependency bindings for Notes.
 */
@Module
@ComponentScan("com.example.feature.notes")
class NotesFeatureModule {
    @Single
    internal fun provideDatabase(): NotesDatabase = createNotesDatabase()

    @Single
    internal fun provideDao(database: NotesDatabase): NotesDao = database.notesDao()
    /**
     * Binds the Notes repository contract to its default.
     */
    @Single
    internal fun bindNotesRepository(impl: DefaultNotesRepository): NotesRepository = impl
}
