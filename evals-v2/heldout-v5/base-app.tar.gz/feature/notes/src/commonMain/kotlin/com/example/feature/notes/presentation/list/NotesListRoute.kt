package com.example.feature.notes.presentation.list

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.LifecycleStartEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.mvi.CollectEffect
import com.example.designsystem.error.HandleAppErrors

@Composable
fun NotesListRoute(viewModel: NotesListViewModel, onEffect: suspend (NotesListUiEffect) -> Unit) {
    LifecycleStartEffect(Unit) {
        viewModel.onAction(NotesListUiAction.OnScreenStarted)
        onStopOrDispose {}
    }
    val state by viewModel.state.collectAsStateWithLifecycle()
    CollectEffect(viewModel.effect) { onEffect(it) }
    HandleAppErrors(viewModel.errors)
    NotesListScreen(
        state = state,
        onAdd = { viewModel.onAction(NotesListUiAction.OnAddClick) },
        onNote = { viewModel.onAction(NotesListUiAction.OnNoteClick(it)) },
        onRetry = { viewModel.onAction(NotesListUiAction.OnRetryClick) },
    )
}
