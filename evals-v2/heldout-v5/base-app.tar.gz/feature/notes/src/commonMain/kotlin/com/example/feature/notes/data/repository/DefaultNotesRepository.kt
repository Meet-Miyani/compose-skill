/**
 * Feature-local implementation of the Notes repository.
 *
 * Maps Room records to domain notes.
 */
package com.example.feature.notes.data.repository

import com.example.feature.notes.data.local.NotesDao
import com.example.feature.notes.data.local.NoteEntity
import com.example.feature.notes.data.local.toDomain
import com.example.feature.notes.domain.model.Note
import com.example.feature.notes.domain.repository.NotesRepository
import org.koin.core.annotation.Factory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Default notes repository backed by Room.
 */
@Factory
internal class DefaultNotesRepository(
    private val dao: NotesDao,
) : NotesRepository {
    override fun getNotesStream(): Flow<List<Note>> = dao.getNotesStream().map { notes -> notes.map(NoteEntity::toDomain) }
    override suspend fun addNote(): Long = dao.insert(NoteEntity())
    /**
     * Reads one note by identity.
     */
    override suspend fun getNote(id: Long): Note? {
        return dao.getNote(id)?.toDomain()
    }

    /**
     * Deletes the note with the given identity.
     */
    override suspend fun deleteNote(id: Long) {
        dao.delete(id)
    }

    /**
     * Persists the editor draft title.
     */
    override suspend fun saveNoteDraft(id: Long, title: String) {
        dao.updateTitle(id, title)
    }
}
