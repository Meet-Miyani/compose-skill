package com.example.feature.notes.data.local

import androidx.room.ConstructedBy
import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.RoomDatabaseConstructor
import androidx.sqlite.driver.bundled.BundledSQLiteDriver

@Database(entities = [NoteEntity::class], version = 1, exportSchema = true)
@ConstructedBy(NotesDatabaseConstructor::class)
internal abstract class NotesDatabase : RoomDatabase() {
    abstract fun notesDao(): NotesDao
}

@Suppress("KotlinNoActualForExpect")
internal expect object NotesDatabaseConstructor : RoomDatabaseConstructor<NotesDatabase> {
    override fun initialize(): NotesDatabase
}

internal expect fun notesDatabaseBuilder(): RoomDatabase.Builder<NotesDatabase>

internal fun createNotesDatabase(): NotesDatabase = notesDatabaseBuilder().setDriver(BundledSQLiteDriver()).build()
