package com.example.feature.notes.presentation.list

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import org.jetbrains.compose.resources.stringResource
import notes.feature.notes.generated.resources.Res
import notes.feature.notes.generated.resources.add_note
import notes.feature.notes.generated.resources.empty_notes
import notes.feature.notes.generated.resources.error_message
import notes.feature.notes.generated.resources.notes_title
import notes.feature.notes.generated.resources.retry
import notes.feature.notes.generated.resources.untitled_note

@Composable
fun NotesListScreen(
    state: NotesListUiState,
    onAdd: () -> Unit,
    onNote: (Long) -> Unit,
    onRetry: () -> Unit,
) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(stringResource(Res.string.notes_title))
        Button(onClick = onAdd) { Text(stringResource(Res.string.add_note)) }
        when {
            state.isLoading -> CircularProgressIndicator()
            state.error != null -> {
                Text(stringResource(Res.string.error_message))
                Button(onClick = onRetry) { Text(stringResource(Res.string.retry)) }
            }
            state.items.isEmpty() -> Text(stringResource(Res.string.empty_notes))
            else -> LazyColumn {
                items(state.items, key = { it.id }) { note ->
                    ListItem(
                        headlineContent = { Text(note.title?.takeIf(String::isNotBlank) ?: stringResource(Res.string.untitled_note)) },
                        modifier = Modifier.clickable { onNote(note.id) },
                    )
                }
            }
        }
    }
}
