package com.example.feature.notes.presentation.list

import com.example.core.mvi.BaseViewModel
import com.example.feature.notes.domain.repository.NotesRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collect
import org.koin.core.annotation.KoinViewModel

@KoinViewModel
class NotesListViewModel(private val repository: NotesRepository) :
    BaseViewModel<NotesListUiAction, NotesListUiState, NotesListUiEffect>(NotesListUiState()) {
    private var streamJob: Job? = null
    private var addJob: Job? = null

    override fun onAction(action: NotesListUiAction) {
        when (action) {
            NotesListUiAction.OnScreenStarted, NotesListUiAction.OnRetryClick -> observeNotes()
            NotesListUiAction.OnAddClick -> addNote()
            is NotesListUiAction.OnNoteClick -> sendEffect(NotesListUiEffect.OpenNote(action.id))
        }
    }

    private fun observeNotes() {
        if (streamJob?.isActive == true) return
        updateState { copy(isLoading = true, error = null) }
        streamJob = launchGuarded(onError = { updateState { copy(isLoading = false, error = it) } }) {
            repository.getNotesStream().collect { notes ->
                updateState { copy(items = notes, isLoading = false, error = null) }
            }
        }
    }

    private fun addNote() {
        if (addJob?.isActive == true) return
        addJob = launchGuarded(onError = ::emitError) {
            sendEffect(NotesListUiEffect.OpenNote(repository.addNote()))
        }
    }
}
