/**
 * Repository port owned by the Notes domain.
 *
 * Notes persistence contract observed by the presentation layer.
 */
package com.example.feature.notes.domain.repository

import com.example.feature.notes.domain.model.Note
import kotlinx.coroutines.flow.Flow

/**
 * Domain repository for Notes records.
 */
public interface NotesRepository {
    public fun getNotesStream(): Flow<List<Note>>
    public suspend fun addNote(): Long
    /**
     * Returns the note with the given identity, or null when absent.
     */
    public suspend fun getNote(id: Long): Note?

    /**
     * Deletes the note with the given identity.
     */
    public suspend fun deleteNote(id: Long)

    /**
     * Persists the editor draft title for the note with the given identity.
     */
    public suspend fun saveNoteDraft(id: Long, title: String)
}
