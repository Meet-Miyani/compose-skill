/**
 * Stateless content for the Notes destination in the Notes example.
 *
 * Renders state only. No ViewModel, no Koin, no state reads beyond params.
 * Every UiState field is read below.
 */
package com.example.feature.notes.presentation.notes

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import org.jetbrains.compose.resources.stringResource
import notes.feature.notes.generated.resources.Res
import notes.feature.notes.generated.resources.back
import notes.feature.notes.generated.resources.error_message
import notes.feature.notes.generated.resources.missing_note
import notes.feature.notes.generated.resources.note_title
import notes.feature.notes.generated.resources.refreshing
import notes.feature.notes.generated.resources.retry
import notes.feature.notes.generated.resources.save

@Composable
fun NotesScreen(
    state: NotesUiState,
    onTitleChange: (String) -> Unit,
    onSave: () -> Unit,
    onRetry: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    when {
        state.isLoading -> CircularProgressIndicator(modifier = modifier)
        state.error != null && state.items.isEmpty() -> Column(modifier = modifier) {
            Text(stringResource(Res.string.error_message))
            Button(onClick = onRetry) { Text(stringResource(Res.string.retry)) }
            Button(onClick = onBack) { Text(stringResource(Res.string.back)) }
        }
        state.isMissing -> Column(modifier = modifier) {
            Text(stringResource(Res.string.missing_note))
            Button(onClick = onBack) { Text(stringResource(Res.string.back)) }
        }
        else -> Column(modifier = modifier) {
            if (state.isRefreshing) {
                Text(stringResource(Res.string.refreshing))
            }
            OutlinedTextField(
                value = state.draftTitle,
                onValueChange = onTitleChange,
                label = { Text(stringResource(Res.string.note_title)) },
            )
            Button(onClick = onSave) { Text(stringResource(Res.string.save)) }
            Button(onClick = onBack) { Text(stringResource(Res.string.back)) }
        }
    }
}
