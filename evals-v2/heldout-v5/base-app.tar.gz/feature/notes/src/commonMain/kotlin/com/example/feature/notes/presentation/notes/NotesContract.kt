/**
 * MVI contract for the Notes destination.
 *
 * Notes example: exactly three top-level declarations live here. UiState
 * holds the domain Note directly (no M-11 trigger fires on this
 * screen); add model/ plus mapper/ only with --ui-model when a trigger
 * fires (see templates/feature/README.md).
 */
package com.example.feature.notes.presentation.notes

import com.example.feature.notes.domain.model.Note
import com.example.core.error.AppError
import com.example.core.mvi.UiAction
import com.example.core.mvi.UiEffect
import com.example.core.mvi.UiState

data class NotesUiState(
    val items: List<Note> = emptyList(),
    val draftTitle: String = "",
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,
    val error: AppError? = null,
    val isMissing: Boolean = false,
) : UiState

sealed interface NotesUiAction : UiAction {
    data object OnScreenStarted : NotesUiAction
    data class OnTitleChanged(val title: String) : NotesUiAction
    data object OnSaveClick : NotesUiAction
    data class OnRetryClick(val error: AppError) : NotesUiAction
    data object OnBackClick : NotesUiAction
}

sealed interface NotesUiEffect : UiEffect {
    data class OpenNotesDetail(val id: Long) : NotesUiEffect
    data object Saved : NotesUiEffect
    data object NavigateBack : NotesUiEffect
}
