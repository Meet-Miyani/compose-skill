/**
 * ViewModel for the Notes destination in the Notes example.
 *
 * Owns the UiState, the draft title (via SavedStateHandle), and the
 * cold-load/reconcile split. Effects carry navigation intent outward.
 */
package com.example.feature.notes.presentation.notes

import com.example.feature.notes.domain.repository.NotesRepository
import androidx.lifecycle.SavedStateHandle
import com.example.core.mvi.BaseViewModel
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import org.koin.core.annotation.KoinViewModel
import org.koin.core.annotation.InjectedParam

/** Construction bag for the destination's nav arguments. Top-level so entries and tests share it. */
data class NotesParams(val noteId: Long)

/** ViewModel behind the Notes destination; owns its UiState, draft title, and cold-load/reconcile split. */
@KoinViewModel
class NotesViewModel(
    private val repository: NotesRepository,
    @InjectedParam private val params: NotesParams,
    private val savedStateHandle: SavedStateHandle,
    // Inject the dispatcher; Default is the commonMain default across targets.
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.Default,
) : BaseViewModel<NotesUiAction, NotesUiState, NotesUiEffect>(
    NotesUiState(draftTitle = savedStateHandle["draftTitle"] ?: ""),
) {

    private var loadJob: Job? = null
    private var saveJob: Job? = null
    private var hasStarted: Boolean = false

    override fun onAction(action: NotesUiAction) {
        when (action) {
            NotesUiAction.OnScreenStarted -> load()
            is NotesUiAction.OnTitleChanged -> {
                savedStateHandle["draftTitle"] = action.title
                updateState { copy(draftTitle = action.title) }
            }
            NotesUiAction.OnSaveClick -> save()
            is NotesUiAction.OnRetryClick -> retry()
            NotesUiAction.OnBackClick -> sendEffect(NotesUiEffect.NavigateBack)
        }
    }

    private fun load() {
        // Overlap guard: the first load owns the response; later overlapping loads return early.
        if (loadJob?.isActive == true) return
        loadJob = launchGuarded(
            onError = { error ->
                if (hasStarted) emitError(error) else updateState { copy(error = error) }
            },
            onStart = { updateState { copy(isLoading = !hasStarted, isRefreshing = hasStarted) } },
            onComplete = { updateState { copy(isLoading = false, isRefreshing = false) } },
        ) {
            val item = withContext(ioDispatcher) { repository.getNote(params.noteId) }
            updateState {
                copy(
                    isLoading = false,
                    isRefreshing = false,
                    isMissing = item == null,
                    items = listOfNotNull(item),
                    draftTitle = if (savedStateHandle.contains("draftTitle")) draftTitle else item?.title.orEmpty(),
                )
            }
            hasStarted = true
        }
    }

    private fun save() {
        if (saveJob?.isActive == true) return
        val draftTitle = currentState.draftTitle
        saveJob = launchGuarded(onError = ::emitError) {
            withContext(ioDispatcher) {
                repository.saveNoteDraft(params.noteId, draftTitle)
            }
            sendEffect(NotesUiEffect.Saved)
        }
    }

    private fun retry() {
        updateState { copy(error = null) }
        load()
    }
}
