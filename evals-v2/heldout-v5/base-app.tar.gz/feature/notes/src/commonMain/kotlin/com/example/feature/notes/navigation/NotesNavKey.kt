/**
 * Navigation keys for the Notes feature.
 *
 * Detail destination key for this feature.
 */
package com.example.feature.notes.navigation

import androidx.navigation3.runtime.NavKey
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.Serializable
import kotlinx.serialization.modules.SerializersModule
import kotlinx.serialization.modules.polymorphic
import kotlinx.serialization.modules.subclassesOfSealed

/**
 * Sealed navigation keys owned by the Notes feature.
 */
@Serializable
sealed interface NotesNavKey : NavKey

@Serializable
data object NotesListKey : NotesNavKey

/**
 * Detail destination key carrying the note identity.
 */
@Serializable
data class NotesDetailKey(val noteId: Long) : NotesNavKey

/**
 * Polymorphic serializers for the Notes key hierarchy.
 */
@OptIn(ExperimentalSerializationApi::class)
val notesNavSerializers = SerializersModule {
    polymorphic(NavKey::class) {
        subclassesOfSealed<NotesNavKey>()
    }
}
