package com.example.feature.notes.data.local

import androidx.room.Room
import androidx.room.RoomDatabase
import platform.Foundation.NSDocumentDirectory
import platform.Foundation.NSFileManager
import platform.Foundation.NSUserDomainMask
import kotlinx.cinterop.ExperimentalForeignApi

@OptIn(ExperimentalForeignApi::class)
internal actual fun notesDatabaseBuilder(): RoomDatabase.Builder<NotesDatabase> {
    val directory = NSFileManager.defaultManager.URLForDirectory(
        NSDocumentDirectory, NSUserDomainMask, null, true, null,
    )?.path ?: error("Documents directory unavailable")
    return Room.databaseBuilder<NotesDatabase>(name = "$directory/notes.db")
}
