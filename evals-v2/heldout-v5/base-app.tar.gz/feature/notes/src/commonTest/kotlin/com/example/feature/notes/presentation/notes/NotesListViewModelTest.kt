package com.example.feature.notes.presentation.notes

import com.example.feature.notes.domain.model.Note
import com.example.feature.notes.presentation.list.NotesListUiAction
import com.example.feature.notes.presentation.list.NotesListUiEffect
import com.example.feature.notes.presentation.list.NotesListViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestCoroutineScheduler
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import kotlin.test.AfterTest
import kotlin.test.BeforeTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse

@OptIn(ExperimentalCoroutinesApi::class)
class NotesListViewModelTest {
    private val scheduler = TestCoroutineScheduler()

    @BeforeTest fun setUp() { Dispatchers.setMain(StandardTestDispatcher(scheduler)) }
    @AfterTest fun tearDown() { Dispatchers.resetMain() }

    @Test fun `observes notes and later changes`() = runTest(scheduler) {
        val fake = FakeNotesRepository()
        val viewModel = NotesListViewModel(fake)
        viewModel.onAction(NotesListUiAction.OnScreenStarted)
        advanceUntilIdle()
        assertFalse(viewModel.state.value.isLoading)
        fake.seed(listOf(Note(7, "First", "", null)))
        advanceUntilIdle()
        assertEquals("First", viewModel.state.value.items.single().title)
    }

    @Test fun `add creates note and opens detail`() = runTest(scheduler) {
        val fake = FakeNotesRepository()
        val viewModel = NotesListViewModel(fake)
        val effects = mutableListOf<NotesListUiEffect>()
        backgroundScope.launch(UnconfinedTestDispatcher(scheduler)) { viewModel.effect.toList(effects) }
        viewModel.onAction(NotesListUiAction.OnScreenStarted)
        viewModel.onAction(NotesListUiAction.OnAddClick)
        advanceUntilIdle()
        assertEquals(1L, viewModel.state.value.items.single().id)
        assertEquals(NotesListUiEffect.OpenNote(1L), effects.single())
    }

    @Test fun `note click opens chosen note`() = runTest(scheduler) {
        val viewModel = NotesListViewModel(FakeNotesRepository())
        val effects = mutableListOf<NotesListUiEffect>()
        backgroundScope.launch(UnconfinedTestDispatcher(scheduler)) { viewModel.effect.toList(effects) }
        viewModel.onAction(NotesListUiAction.OnNoteClick(42L))
        advanceUntilIdle()
        assertEquals(NotesListUiEffect.OpenNote(42L), effects.single())
    }
}
