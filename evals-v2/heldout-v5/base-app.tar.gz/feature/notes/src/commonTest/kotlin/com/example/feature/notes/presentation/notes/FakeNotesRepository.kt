/**
 * Hand-written fake of the Notes repository for `commonTest`.
 *
 * Tests own this fake's behaviour through [seed] and [shouldThrow].
 * Never a mocking library; swap fakes via constructor injection.
 */
package com.example.feature.notes.presentation.notes

import com.example.feature.notes.domain.model.Note
import com.example.feature.notes.domain.repository.NotesRepository
import com.example.core.error.NetworkException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.update

/** Test-only fake backing the Notes ViewModel tests. */
class FakeNotesRepository : NotesRepository {
    // One mutation path only: tests assign this directly. A fun
    // setShouldThrow next to this var shares its JVM signature and fails
    // compileTestKotlinJvm with a platform declaration clash, so it stays out.
    var shouldThrow: NetworkException? = null

    /** When set, one-shot reads suspend until the test completes it, so in-flight states stay observable. */
    var gate: CompletableDeferred<Unit>? = null
    private val backing = MutableStateFlow<List<Note>>(emptyList())

    /** Counts one-shot reads; the overlap test asserts the guard keeps this at one. */
    var getCalls: Int = 0

    /** Last draft the fake was asked to persist; the save test asserts this. */
    var lastSavedDraft: Pair<Long, String>? = null
    var saveCalls: Int = 0

    /** Test-only helper that replaces the stored list. */
    fun seed(items: List<Note>) {
        backing.value = items
    }

    override fun getNotesStream(): Flow<List<Note>> = backing

    override suspend fun addNote(): Long {
        val id = (backing.value.maxOfOrNull { it.id } ?: 0L) + 1L
        backing.update { it + Note(id, "", "", null) }
        return id
    }

    override suspend fun getNote(id: Long): Note? {
        gate?.await()
        getCalls += 1
        shouldThrow?.let { throw it }
        return backing.value.firstOrNull { it.id == id }
    }

    override suspend fun deleteNote(id: Long) {
        backing.update { list -> list.filterNot { it.id == id } }
    }

    override suspend fun saveNoteDraft(id: Long, title: String) {
        saveCalls += 1
        lastSavedDraft = id to title
        backing.update { list -> list.map { if (it.id == id) it.copy(title = title) else it } }
    }
}
