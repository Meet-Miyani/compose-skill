# Feature templates

Scaffold for a Notes slice. Copy the files, replace the placeholders, keep the layout.

## Placeholders

| Placeholder | Meaning | Example (Notes) |
|---|---|---|
| `Notes` | Feature name, PascalCase | `Notes` |
| `notes` | Feature name, camelCase | `notes` |
| `Note` | Record name, singular PascalCase | `Note` |
| `note` | Record name, singular camelCase | `note` |
| `com.example.feature.notes` | Feature package root | `com.example.feature.notes` |

## Scaffold

Run from the project root:

```sh
scripts/new-feature.sh --name Notes --item Note --package com.example.feature.notes --root <project-root>
```

The default scaffold holds the domain `Note` in `UiState` directly: no `model/`, no `mapper/` (ruling M-11). Add `--ui-model` to also write `NoteUiModel` and `NoteUiMapper` when a trigger fires; name that trigger in the one-line comment on the UiModel. `UI_MODEL=always` in `.composekit.conf` makes `--ui-model` the default (`--no-ui-model` forces it off).

The script copies `templates/feature/` and renames `Notes`, `notes`, `Note`, `note`, and `com.example.feature.notes` in paths and contents.

Register the generated `NotesFeatureModule` in the composition root's Koin module after scaffolding. *Prevents:* a destination whose ViewModel has no binding.

## Composition-root entry

Entries live in the composition root, never in the feature. Register the detail key there:

```kotlin
entry<NotesDetailKey> {
    NotesRoute(
        viewModel = koinViewModel(parameters = { parametersOf(NotesParams(noteId = it.noteId)) }),
        noteId = it.noteId,
        onEffect = { effect -> /* composition root maps the effect to a back-stack call */ },
    )
}
```

The entry resolves the ViewModel with `parametersOf` and passes it into the Route. The feature owns the key and the Route; the composition root owns the entry. Entry mechanics follow the android/skills `navigation-3` skill, if installed. `NotesParams` is a top-level class shared by the entry and the tests.
